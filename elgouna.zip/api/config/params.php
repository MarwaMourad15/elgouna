<?php
return [

    'adminEmail' => 'marwa_mourad_2011@yahoo.com',
    'siteLink'=>'http://localhost/FumeStudio/yadoctory/frontend/web',
    'RootLink'=>'http://localhost/FumeStudio/yadoctory',
    //'siteLink'=>'http://hitechawy.com/yadoctory/frontend/web/',
    //'RootLink'=>'http://hitechawy.com/yadoctory/',
];
