<?php

use yii\helpers\Html;
use yii\grid\GridView;

/* @var $this yii\web\View */
/* @var $searchModel backend\models\UsersSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = Yii::t('app', 'Users');
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="users-index">

    <h1><?= Html::encode($this->title) ?></h1>
    <?php // echo $this->render('_search', ['model' => $searchModel]); ?>

    <p>
        <?= Html::a(Yii::t('app', 'Create Users'), ['create'], ['class' => 'btn btn-success']) ?>
    </p>
    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],

            'id',
            'userAuth:ntext',
            'name:ntext',
            'imageURL:ntext',
            'phoneNumber:ntext',
            // 'gender',
            // 'birthDate:ntext',
            // 'address:ntext',
            // 'email:ntext',
            // 'zipCode:ntext',
            // 'notificationsEnabled',
            // 'mapsEnabled',
            // 'elgounaPhone:ntext',
            // 'elgounaSMS:ntext',
            // 'elgounaemail:ntext',
            // 'fbId:ntext',
            // 'ehgzly_user_token',
            // 'ehgzly_user_id',
            // 'auth_reset_token',

            ['class' => 'yii\grid\ActionColumn'],
        ],
    ]); ?>
</div>
