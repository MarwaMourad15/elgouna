<?php
/**
 * Created by PhpStorm.
 * User: funson
 * Date: 2014/10/25
 * Time: 10:33
 */

return [

    'Name' => '名称',
    'Description' => '描述',
    'Company ID' => '公司名称',
    'Operation List' => '权限列表',


    'goods' => '商品管理',
    'cat_manage' => '类别管理',
    'cat_drop' => '类别删除',

];