<?php
return [
    'adminEmail' => 'marwa_mourad_2011@yahoo.com',
];
